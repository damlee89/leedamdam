// mongojs 모듈 불러오기
// 초창기 Node.js 에서 활용하던 방식 
const mongojs = require('mongojs')
const db = mongojs("vehicle",["car"]);
db.car.find(function(err, data){
    console.log(data);
});


/*
npm i -S mongojs
npm i -S mongodb
*/



