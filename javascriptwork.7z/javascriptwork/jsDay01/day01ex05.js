/*day01ex05.js - typeof 연산자 */
// typeof연산자는 데이터의 자료형을 알고자 할 때 사용
//typeof 연산자를 사용 할 때는 함수처럼 사용 가능

console.log(typeof(500));
console.log(typeof("Hello"));
console.log(typeof null);
console.log(typeof undefined);


var name;
console.log('name의 타입은', typeof name);
//null 과 undefined는 다르다. 
name = '김길동';
console.log('name',name);

console.log(typeof NaN);

//자바 스크립트에서는 모든 요소가 객체로 취급된다.
//자바의 경우 : B -> C -> C++(스몰토크 에서 객체지향 개념이옴) 
// -> JAVA

//자바스크립트 의 경우 Lisp 언어로 부터 계승된 언어다.
// R언어도 Lisp으로 부터 물려 받음  