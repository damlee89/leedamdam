
let arr = [25,365,'김길동','홍길동', true, false];
// array;
// console.log(array);

// console.log(array[0]);
// console.log(array[1]);
// console.log(array[2]);
// console.log(array[3]);
// console.log(array[4]);
// console.log(array[5]);

//while문을 이용해서 배열 요소 출력하기
// let idx =0;
// while(idx<arr.length){
//     console.log(idx+"."arr[idx]);
//     //중요 while문에서는 반드시 증감식을 꼭 넣을것  .. 끝나는조건 
//     idx += 1;

// }

//while문을 포

for(let idx =0; idx <arr.length ; idx += 1){
    console.log(idx+"."+arr[idx]);
    //중요 while문에서는 반드시 증감식을 꼭 넣을것  .. 끝나는조건 
        
}