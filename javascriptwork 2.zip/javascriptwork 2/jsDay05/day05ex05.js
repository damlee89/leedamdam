function AAA(){
    console.log('AAA');
    let name = "홍길동";
    //자바 스크립트의 클로저 개념
    function sayHello(){
        console.log("hello" + name);
    }
    return sayHello;
}

let sayHello =AAA();

sayHello();
