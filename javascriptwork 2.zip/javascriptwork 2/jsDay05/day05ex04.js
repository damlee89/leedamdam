

function test01(){
let output = 1;
for(let i =1; i<=20; i++){
    output*= i ;
}
console.log(output);
}

let arr = ["사과","배","포도","딸기","바나나"];


function test02(){
    
    //for in 문으로 배열의 요소 출력하기
    for(let i in arr){
        console.log(`${i}번째는 ${arr[i]}입니다`)
    }
}


function test03(){
for (let item of arr){
    console.log(item);
    }
}


function test04(){
    let a =1;

    {//인터프리터 이므로 블럭안에 a가 아직 선언 되지 않았다.
        //not defined
        console.log(a); //error 
        let a =2;
    }    
}


//var 로 선언 한 변수는 scope 가 함수 단위이다.
var a = 1;
function test05(){
    
    //인터프리터이므로 호이스팅이 발생한다.
    
    console.log(a);
    var a =2 ;          
}

test05();



