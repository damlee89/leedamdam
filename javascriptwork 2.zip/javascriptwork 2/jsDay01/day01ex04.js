/*day01ex04.js*/
//자바 스크립트 연산자와 자바 연산자는 거의 동일 하다.
// =, ==, === 
// =   : 대입 연산자
// ==  : 부등호  (!=)  얼추 비슷한것
// === : 부등호  (!==) 타입까지 같은것이 참

console.log(100 == '100')  // true
console.log(100 === '100') // false


var name = '홍길동';
var name = '김길동'; // var로 변수를 선언 할때는 기존 변수와 같은 
                    //식별자로 선언 가능
                    //변수의 scopr가 함수단위이다.

console.log('name',name);

let name2 = '박길동';
let name2 = '최길동'; // let으로 같은 변수를 선언하면 
                    // 같은 식별자를 사용 할 수 없고
                    //변수의 scopr가 블럭단위이다.
console.log('name',name);