/* 파일명 : day01ex01.js
   작성자 : 이담
   이메일 : comstudy21@naver.com
   작성일 : 2020-10-21
*/
// 이것은 한줄 주석

//자바스크립트에서 변수 선언하기 var , let 키워드사용 
//var나 let을 안쓰면 전역변수이다.
var title = "Nodejs 시작하기";
var name = "Node.js";

console.log(title);
console.log("Hello",name);